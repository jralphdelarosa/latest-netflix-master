package com.example.myfirstandroidtvapp.data.remote.dto

data class TrailerResponse(
    val url: String = "",
    val duration: Double? = null
)