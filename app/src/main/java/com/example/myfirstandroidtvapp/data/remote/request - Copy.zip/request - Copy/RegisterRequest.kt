package com.example.myfirstandroidtvapp.data.remote.request

data class RegisterRequest(
    val username: String,
    val password: String,
    val email: String
)